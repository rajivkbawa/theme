jQuery(document).ready(function(){
	jQuery('.my-grid').WMGridfolio();
});